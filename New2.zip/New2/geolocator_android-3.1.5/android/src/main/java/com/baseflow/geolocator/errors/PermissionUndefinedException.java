package com.baseflow.geolocator.errors;

public class PermissionUndefinedException extends Exception {}
