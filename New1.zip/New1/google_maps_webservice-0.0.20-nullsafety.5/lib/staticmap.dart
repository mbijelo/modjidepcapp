library google_maps_webservice.staticmap;

export './src/core.dart';
export './src/staticmap.dart';
