# Examples

- [Directions API](https://github.com/lejard-h/google_maps_webservice/blob/master/example/directions.dart)
- [Distance API](https://github.com/lejard-h/google_maps_webservice/blob/master/example/distance.dart)
- [Geolocation API](https://github.com/lejard-h/google_maps_webservice/blob/master/example/geolocation.dart)
- [Places API](https://github.com/lejard-h/google_maps_webservice/blob/master/example/places_autocomplete.dart)
- [Static MAP API](https://github.com/lejard-h/google_maps_webservice/blob/master/example/staticmap.dart)